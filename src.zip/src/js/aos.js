AOS.init({
	startEvent: 'DOMContentLoaded',
	offset: 200,
	once: true,
	duration: 600,
})
